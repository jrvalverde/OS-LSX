/*
 * This file is part of BKUNIX project, which is distributed
 * under the terms of the GNU General Public License (GPL).
 * See the accompanying file "COPYING" for more details.
 */
#ifndef _SYS_TYPES_H_
#define _SYS_TYPES_H_ 1

/* Nothing to declare yet. */

#endif /* _SYS_TYPES_H_ */
